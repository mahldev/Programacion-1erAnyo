package ejercicio2;

public class EmpleadoTCompleto extends Empleado {

    public EmpleadoTCompleto(String nombre, int edad, double salario) {
        super(nombre, edad, salario);
    }
}
